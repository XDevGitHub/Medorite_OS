import time
import os
from tkinter import *
import json
import urllib.request


Q1 = input(""""
What Would You Like To Do?

[1]. Sign In To Current Account.
[2]. Sign Up (Will Replace Old User If An Account Is Already Set-Up)""")


if Q1 == '2':
    Print("Tearms of service")
    Print("[1] You are not alowed to make ilegall copy's of this software.Doing so Is a violation of the Copeyright law")
    Print("Please note that all your Username's and password's are securely encrypeted")
    Password = input('Please Enter Your Password: ')
    Username = input('Please Enter Your Username')
    while True:
        def doesFileExists(filePathAndName):
            return os.path.exists(filePathAndName)


        if doesFileExists('./Password.txt'):
            with open('Password.txt') as f:
                contents = f.read()
            if contents == Password:
                UserNameS = input('Please Enter Your New Username: ')
                PasswordS = input('Please Enter Your New Password: ')
                with open('Username.txt', 'w') as f:
                    f.write(UserNameS)
                with open('Password.txt', 'w') as f:
                    f.write(PasswordS)
                    break

                    if Q1 == '1':
                        UserName = input('Please Enter Your Username: ')
                        Password = input('Please Enter Your Password: ')

                        with open('Username.txt') as f:
                            contents = f.read()
                        with open('Password.txt') as f:
                            contents = f.read()
                    while True:
                        if contents == Password:
                            print('Login Successful')
                            time.sleep(1)
                            print('Welcome To Medorite_OS Version 2 '.format(UserName))
                            MainMenu = input("""
                                     What would you like to do                            
                                     [1]. Exit-OS
                                     [2]. Calculator
                                     [3]. Weather                     
                                     """)
                            break
    else:
        print('Access Denied')
        print('The Program Will Now Shutdown!')
        time.sleep(3.10)
        exit()
                
if Q2 == '2':
       # Program make a simple calculator

# This function adds two numbers
  def add(x, y):
    return x + y

# This function subtracts two numbers
def subtract(x, y):
    return x - y

# This function multiplies two numbers
def multiply(x, y):
    return x * y

# This function divides two numbers
def divide(x, y):
    return x / y


print("Select operation.")
print("1.Add")
print("2.Subtract")
print("3.Multiply")
print("4.Divide")

while True:
    # take input from the user
    choice = input("Enter choice(1/2/3/4): ")

    # check if choice is one of the four options
    if choice in ('1', '2', '3', '4'):
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        if choice == '1':
            print(num1, "+", num2, "=", add(num1, num2))

        elif choice == '2':
            print(num1, "-", num2, "=", subtract(num1, num2))

        elif choice == '3':
            print(num1, "*", num2, "=", multiply(num1, num2))

        elif choice == '4':
            print(num1, "/", num2, "=", divide(num1, num2))
        
        # check if user wants another calculation
        # break the while loop if answer is no
        next_calculation = input("Let's do next calculation? (yes/no): ")
        if next_calculation == "no":
          break
    
    else:
        print("Invalid Input")
        break

    if Q2 == '3':
        def weather():
            global la
            global img1
            global mylabe0
            global glcolor
            mylabe0.grid_forget()

            api_request = requests.get(
                "http://api.openweathermap.org/data/2.5/weather?q=" + e.get() + "&appid=<<INSERT API KEY HERE>>")
            api = json.loads(api_request.content)
            icondata = api['weather'][0]['icon']
            path = "C:/Users/New/Desktop/python projects/weather app/w1.png"
            urllib.request.urlretrieve("http://openweathermap.org/img/w/" + icondata + ".png", path)
            img = Image.open("w1.png")
            resized = img.resize((120, 120), Image.ANTIALIAS)
            img1 = ImageTk.PhotoImage(resized)
            la = Label(image=img1, bg=glcolor)
            la.grid(row=3, column=0)
            temp = str(int(api['main']['temp'] - 273)) + "°C"
            temp_feel = "Feels like:" + str(int(api['main']['feels_like'] - 273)) + "° C"
            temp_min = "Temprature min:" + str(int(api['main']['temp_min'] - 273)) + "° C"
            temp_max = "Temprature max:" + str(int(api['main']['temp_max'] - 273)) + "° C"
            humid = "Humidity:" + str(int(api['main']['humidity']))
            desc = api['weather'][0]['description']
            mylabe0 = Label(root, text=desc, bg=glcolor, fg="white", font=('arial', 20))
            mylabe0.grid(row=5, column=0)

            mylabel = Label(root, text=temp, bg=glcolor, fg="white", font=('arial', 40, 'bold'))
            mylabel.grid(row=4, column=0)
            mylabel1 = Label(root, text=temp_feel, bg=glcolor, fg="white", font=('arial', 10))
            mylabel1.grid(row=6, column=0)
            mylabel2 = Label(root, text=temp_min, bg=glcolor, fg="white", font=('arial', 10))
            mylabel2.grid(row=7, column=0)
            mylabel3 = Label(root, text=temp_max, bg=glcolor, fg="white", font=('arial', 10))
            mylabel3.grid(row=8, column=0)
            mylabel4 = Label(root, text=humid, bg=glcolor, fg="white", font=('arial', 10))
            mylabel4.grid(row=9, column=0)
            glcolor = "green"
            root = Tk()
            root.configure(bg="green")
            root.title("weather app")
            root.iconbitmap('weather_128.ico')

            img = Image.open("w1.png")
            resized = img.resize((120, 120), Image.ANTIALIAS)
            img1 = ImageTk.PhotoImage(resized)

            la = Label(image=img1, bg=glcolor)
            la.grid(row=3, column=0)

            mylabe = Label(root, text="Enter your city name", bg=glcolor, fg="white")
            mylabe.grid(row=0, column=0)
            mylabe0 = Label(root, text="",bg=glcolor, fg="white", font=('arial', 20, 'italic'))
            mylabe0.grid(row=5, column=0)

            e = Entry(root, width=40, bg=glcolor, fg="white")
            e.grid(row=1, column=0, padx=10, pady=10)
            but = Button(root, text="Enter", command=weather, bg=glcolor, fg="white")
            but.grid(row=2, column=0)
            root.mainloop()

